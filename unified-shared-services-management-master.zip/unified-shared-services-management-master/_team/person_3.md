---
layout: teammate
name: Person Three
image: /assets/img/team/team-placeholder.jpg
title: Title here
body-class: page-team-single
---
This is a bio for a team member. It will show up on their individual team member page. The name, title and image will be show on the team list page.

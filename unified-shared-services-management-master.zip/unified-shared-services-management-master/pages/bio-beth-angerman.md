---
layout: pageright
title: Beth Angerman - Executive Director
permalink: /bio-beth-angerman/
image: /assets/img/bio-beth-angerman.png
---
Beth Angerman is the Executive Director of the new Unified Shared Service Management Office in GSA, responsible for working closely with OMB, the new >governance board, providers, and customers to implement the enterprise-wide vision for mission-support functions across government. Beth is a change agent motivated by collaborative stakeholder engagement and delivering results. She’s driven to lead strategies for government to be better stewards of taxpayer dollars and to help Federal organizations deliver missions better, faster, and cheaper.


For this work she has received FCW’s Federal 100, FedScoop’s Top 50 Women in Technology and was recognized as the Association of Government Accountant’s Employee of the Year for the DC Chapter in 2016.


Prior to GSA, Beth served as the Executive Director of the Office of Financial Innovation and Transformation (FIT) in the Treasury Department to address the need for greater efficiency and transparency in the Federal financial environment. Prior to FIT, Beth held several leadership positions in the Bureau of Fiscal Service in the Treasury Department leading government-wide projects and running IT and accounting support organizations. She began her career working as a management consultant in the communications sector.


Beth loves to spend her personal time exploring the outdoors with her husband, and teaching their two sons to rock climb, scuba dive, and camp.
